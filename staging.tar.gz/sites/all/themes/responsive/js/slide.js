jQuery(document).ready(function() {

/* Slider */	
	
 jQuery('.flexslider').flexslider({
  controlNav: false,
  directionNav:true,
  animation: "fade",              //String: Select your animation type, "fade" or "slide"
  slideshow: true                //Boolean: Animate slider automatically
  });

});